import csv, json
from pathlib import Path
root=Path(__file__).parents[1]
rows=list(csv.DictReader((root/'framework/data/spectra_techniques.csv').open(encoding='utf-8')))
assert len(rows)==120
assert len({r['spectra_id'] for r in rows})==120
required={'spectra_id','phase','technique','assessment_question','preconditions','evidence_required','detection_opportunity','defensive_breakpoint','mission_effect','recovery_test'}
assert required.issubset(rows[0])
assert all(all(r[k].strip() for k in required) for r in rows)
json.loads((root/'framework/schema/assessment.schema.json').read_text())
print(f'SPECTRA validation passed: {len(rows)} techniques')
