---
name: New SPECTRA Technique
about: Propose a practical and testable technique
---
## Problem
## Proposed technique
## Mission/domain
## Preconditions
## Assessment question
## Safe test environment
## Evidence
## Detection opportunity
## Defensive breakpoint
## Mission effect
## Recovery test
## Why this is novel within SPECTRA
## References
