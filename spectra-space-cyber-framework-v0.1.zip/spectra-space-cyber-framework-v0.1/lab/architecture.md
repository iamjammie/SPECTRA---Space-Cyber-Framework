# SPECTRA Cyber Range / HIL Architecture

```text
SPECTRA Assessment Workstation
          │
  ┌───────┴────────┐
  │                │
Security Telemetry Mission Telemetry
  │                │
  └───────┬────────┘
          ▼
 Ground Segment Simulation
 MOC / Gateway / Identity / Logs
          │
     Link Simulator
          │
          ▼
 Spacecraft Digital Twin / HIL
 OBC / Payload / Avionics / Fault Mgmt
```

Use disconnected or explicitly isolated environments for practical exercises.
