# Practical Exercise Catalogue

| ID | Scenario | Primary measurement |
|---|---|---|
| EX-01 | Ground identity misuse | Detection latency |
| EX-02 | Maintenance interface exposure | Breakpoint effectiveness |
| EX-03 | Command authority boundary | Unauthorized-command prevention |
| EX-04 | Telemetry state deception | Decision integrity |
| EX-05 | Enterprise-to-ground transit | Attack-path interruption |
| EX-06 | Firmware persistence/recovery | Trusted reconstitution |
| EX-07 | Command-channel disruption | Mission continuity |
| EX-08 | Recovery-path compromise | Recovery independence |
| EX-09 | Full attack-path purple team | End-to-end resilience |
