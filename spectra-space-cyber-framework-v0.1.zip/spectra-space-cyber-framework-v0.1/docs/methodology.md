# SPECTRA Methodology

SPECTRA treats the attack path as the basic unit of analysis. Each technique must be connected to preconditions, evidence, detection, a defensive breakpoint, mission effect and recovery.

Adversary state: Observe → Position → Influence → Control → Survive → Traverse → Manipulate → Affect.

Defender state: Know → Expose → Prevent → Detect → Break → Contain → Continue → Reconstitute → Learn.

The framework is informed by existing space and embedded-system research but intentionally uses an original mission/path/evidence/recovery structure.
