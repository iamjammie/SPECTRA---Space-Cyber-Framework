# Roadmap

## v0.1
120 techniques, 20 controls, mission effects, assessment schema, scoring, playbooks, lab architecture and exercises.

## v0.2
Attack-path graphing, evidence attachments, automated scoring and coverage dashboard.

## v0.3
Cyber-range scenarios, embedded-device scenarios, mission-state simulation and recovery validation.

## v0.4
Telemetry catalogue, detection requirements and response playbooks.

## v1.0
Peer review, stable IDs, contribution governance and published validation results.
