# Recovery Validation

Establish test state → contain → preserve independent evidence → activate trusted recovery → verify software/configuration/trust → restore mission-essential service → compare against baseline → measure recovery time → record residual risk.

Distinguish service restoration from trusted restoration and mission restoration.
