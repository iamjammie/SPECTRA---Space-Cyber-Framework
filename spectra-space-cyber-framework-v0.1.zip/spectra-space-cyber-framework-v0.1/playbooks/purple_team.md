# Purple-Team Validation

Red demonstrates a controlled state transition. Blue demonstrates visibility, detection, triage, containment, mission continuity and recovery. A successful exploit alone is **not** a successful SPECTRA assessment.

Record transition time, detection latency, response latency, containment time, mission degradation, recovery time and evidence completeness.
