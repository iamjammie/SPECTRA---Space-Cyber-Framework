# Attack-Path Assessment

1. Define mission function and authorization.
2. Establish a known-good baseline.
3. Select SPECTRA technique and document preconditions.
4. Use an isolated lab, digital twin, HIL or explicitly approved environment.
5. Define the intended state transition and expected telemetry.
6. Execute only the minimum controlled validation necessary.
7. Record the first effective defensive breakpoint.
8. Measure detection, response and containment latency.
9. Score mission continuity.
10. Validate trusted recovery where authorized.
11. Attach evidence and record engineering action.

Stop if test isolation is lost, an unsafe state occurs, or effects exceed approved scope.
