# SPECTRA Scoring

**Inherent Risk = Likelihood × Mission Criticality × Exposure × Consequence** (1–5 each; maximum 625).

**Residual Risk = Inherent Risk × (1 − average Prevention/Detection/Response/Recovery effectiveness / 100).**

Mission continuity is independently scored 0–5:

0 stop; 1 severe degradation; 2 limited essential capability; 3 essential capability with major restrictions; 4 essential capability with minor restrictions; 5 mission objectives remain achievable.

Maturity: 0 unknown; 1 claimed; 2 implemented; 3 evidenced; 4 adversarially tested; 5 repeatedly validated under realistic mission conditions.
